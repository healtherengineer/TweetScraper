--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE tweets;
--
-- Name: tweets; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE tweets WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Turkish_Turkey.1254';


ALTER DATABASE tweets OWNER TO postgres;

\connect tweets

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tweets_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tweets_users (
    id integer NOT NULL,
    created_date date,
    name character varying(255),
    content text
);


ALTER TABLE public.tweets_users OWNER TO postgres;

--
-- Name: tweets_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tweets_users ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tweets_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: tweets_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tweets_users (id, created_date, name, content) FROM stdin;
\.
COPY public.tweets_users (id, created_date, name, content) FROM '$$PATH$$/3306.dat';

--
-- Name: tweets_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tweets_users_id_seq', 138, true);


--
-- Name: tweets_users tweets_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tweets_users
    ADD CONSTRAINT tweets_users_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

